#ifndef NORMALSPACE_HPP
#define NORMALSPACE_HPP
#include "space.hpp"

class NormalSpace : public Space
{
	public:
		void spawn();
		NormalSpace();
};
#endif
