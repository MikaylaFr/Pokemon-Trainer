#include "normalSpace.hpp"

NormalSpace::NormalSpace()
{
	up = nullptr;
	down = nullptr;
	left = nullptr;
	right = nullptr;
}


void NormalSpace::spawn()
{

}
