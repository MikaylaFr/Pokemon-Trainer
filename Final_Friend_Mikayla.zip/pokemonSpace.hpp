#ifndef POKEMONSPACE_HPP
#define POKEMONSPACE_HPP
#include "space.hpp"

class PokemonSpace : public Space
{
	public:
		PokemonSpace();
		void spawn();
};
#endif
