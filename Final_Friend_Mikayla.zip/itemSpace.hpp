#ifndef ITEMSPACE_HPP
#define ITEMSPACE_HPP
#include "space.hpp"

class ItemSpace : public Space
{
	public:
		ItemSpace();
		void spawn();
};
#endif
